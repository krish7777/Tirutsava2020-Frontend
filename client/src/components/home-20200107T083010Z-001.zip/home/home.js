import React from "react";
import "./home.css";
import Image from "./ppng.png";
import Logo from "./logo.png";

export default function home() {
  return (
    <div style={{ maxWidth: "100vw", maxHeight: "100vh" }}>
      <div>
        <div class="stars"></div>
        <div class="twinkling"></div>
        <div class="clouds"></div>
      </div>
      <div>
        <img
          src={Logo}
          style={{
            backgroundSize: "cover",
            maxWidth: "100vw",
            position: "absolute",
            left: "0",
            right: "0",
            // bottom: "0",
            // height: "300px",
            zIndex: "1000",
            width: "100%",
            maxHeight: "100vh"
          }}
        />
      </div>
      <div style={{}}>
        <img
          style={{
            backgroundSize: "cover",
            maxWidth: "100vw",
            position: "absolute",
            left: "0",
            right: "0",
            bottom: "0",
            height: "300px",
            zIndex: "100",
            width: "100%"
          }}
          src={Image}
        />
      </div>
    </div>
  );
}
